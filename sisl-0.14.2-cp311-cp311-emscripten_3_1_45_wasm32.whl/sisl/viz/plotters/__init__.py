"""Functions that generate plot actions to be passed to figures."""

from . import plot_actions