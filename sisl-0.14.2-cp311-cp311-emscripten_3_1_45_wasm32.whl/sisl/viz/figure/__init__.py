from .figure import BACKENDS, Figure, get_figure


class NotAvailableFigure(Figure):

    _package: str = ""

    def __init__(self, *args, **kwargs):
        raise ModuleNotFoundError(f"{self.__class__.__name__} is not available because {self._package} is not installed.")

try:
    import plotly
except ModuleNotFoundError:
    class PlotlyFigure(NotAvailableFigure):
        _package = "plotly"
else:
    from .plotly import PlotlyFigure

try:
    import matplotlib
except ModuleNotFoundError:
    class MatplotlibFigure(NotAvailableFigure):
        _package = "matplotlib"
else:
    from .matplotlib import MatplotlibFigure

try:
    import py3Dmol
except ModuleNotFoundError:
    class Py3DmolFigure(NotAvailableFigure):
        _package = "py3Dmol"
else:
    from .py3dmol import Py3DmolFigure

try:
    import bpy
except ModuleNotFoundError:
    class BlenderFigure(NotAvailableFigure):
        _package = "blender (bpy)"
else:
    from .blender import BlenderFigure


BACKENDS["plotly"] = PlotlyFigure
BACKENDS["matplotlib"] = MatplotlibFigure
BACKENDS["py3dmol"] = Py3DmolFigure
BACKENDS["blender"] = BlenderFigure
