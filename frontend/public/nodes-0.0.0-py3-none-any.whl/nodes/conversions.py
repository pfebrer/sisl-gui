import importlib
import inspect

from typing import Dict, List

from collections import defaultdict
from dataclasses import dataclass

from .node import ConstantNode, Node

def node_to_python_script(output_node: Node, include_defaults: bool = False, names_map: Dict[int, str] = {}):

    variables = {}

    @dataclass
    class DeclaredVariable:
        id: int

        def __repr__(self):
            return variables[self.id]["key"]
      
    def scrape(key, node):

        if id(node) in variables:
            return

        variable = {}

        if isinstance(node, ConstantNode):
            variable['type'] = "constant"
            variable['value'] = node.inputs["value"]
        else:
            vars = {}
            for k, v in node._inputs.items():

                if k == node._args_inputs_key:
                    if len(v) > 0 and isinstance(v[0], Node):
                        for i, arg_node in enumerate(v):
                            node_name = names_map.get(id(arg_node), f"{k}_{i}").replace(" ", "_")
                            scrape(node_name, arg_node)
            
                        vars[k] = [DeclaredVariable(id(arg_node)) for arg_node in v]
                elif k == node._kwargs_inputs_key:
                    if len(v) > 0 and isinstance(list(v.values())[0], Node):
                        for kwarg_key, kwarg_node in v.items():
                            node_name = names_map.get(id(kwarg_node), kwarg_key).replace(" ", "_")
                            scrape(node_name, kwarg_node)

                        vars[k] = {kwarg_key: DeclaredVariable(id(kwarg_node)) for kwarg_key, kwarg_node in v.items()}
                elif isinstance(v, Node):
                    node_name = names_map.get(id(v), k).replace(" ", "_")
                    scrape(node_name, v)
    
                    vars[k] = DeclaredVariable(id(v))

            all_inputs = {**node._inputs, **vars}
            default_inputs = dict(node.default_inputs).copy()

            module = node.__module__.replace("nodified_", "")
            func_name = node.__class__.__name__

            func = getattr(importlib.import_module(module), func_name)
            args = []
            if hasattr(func, "registry"):
                # This is a singledispatch function
                first_arg = list(node.__signature__.parameters.keys())[0]
                if first_arg in all_inputs:
                    args.append(all_inputs.pop(first_arg))
                    default_inputs.pop(first_arg, None)
            args.extend(all_inputs.pop(node._args_inputs_key, []))
            default_inputs.pop(node._args_inputs_key, None)

            kwargs = {}
            kwargs.update(all_inputs.pop(node._kwargs_inputs_key, {}))
            kwargs.update(all_inputs)
            for k in kwargs:
                default_inputs.pop(k, None)
            default_inputs.pop(node._kwargs_inputs_key, None)

            variable.update({
                "type": "function",
                "module": module,
                "name": func_name,
                "args": args,
                "kwargs": kwargs,
                "default_inputs": default_inputs,
            })
        
        variables[id(node)] = {"key": key, **variable}

    output_name = names_map.get(id(output_node),"output").replace(" ", "_")

    scrape(output_name, output_node)

    def build_script(variables, include_defaults: bool = False):

        # Avoid duplicate variable names and create a list with all names
        variable_names = []
        for var in variables.values():
            if "key" not in var:
                continue
            var["key"] = var["key"].replace(" ", "_")

            orig_name = var["key"]
            if var["key"] in variable_names:
                i = 1
                while var["key"] in variable_names:
                    var["key"] = orig_name + f"_{i}"
                    i += 1
            
            variable_names.append(var["key"])

        constants = [variable for variable in variables.values() if variable["type"] == "constant"]
        functions = [variable for variable in variables.values() if variable["type"] == "function"]

        script = ""

        # Write imports
        imports = defaultdict(list)
        for var in variables.values():
            if "module" not in var:
                continue

            module = var["module"]
            name = var["name"]
            if name in variable_names:
                name = None
                var['script_name'] = f"{module}.{var['name']}"

            imports[module].append(name)
        imports = {k: list(set(v)) for k, v in imports.items()}

        def _get_import_string(module, names):
            if len(names) == 1 and names[0] is None:
                return f"import {module}"
            
            pre = ""
            if any([name is None for name in names]):
                pre = f"import {module}\n"
            return pre + f"from {module} import {','.join([name for name in names if name is not None])}"

        script += "\n".join([_get_import_string(module, names) for module, names in imports.items()])

        script += "\n\n# -------------------\n#    VARIABLES\n# -------------------\n\n"
        for const in constants:
            script += f"{const['key']} = {repr(const['value'])} \n"

        script += "\n# -------------------\n#    COMPUTATION\n# -------------------\n\n"

        def _write_func(func, script):
            
            script += f"{func['key']} = {func.get('script_name', func['name'])}("

            # Add positional args
            if len(func['args']) > 0:
                script += ",".join([repr(arg) for arg in func['args']]) + ","

            # Add keyword args
            if len(func['kwargs']) > 0:
                script += ",".join([f"{k}={repr(v)}" for k, v in func['kwargs'].items()]) + ","
            
            if include_defaults and len(func['default_inputs']) > 0:
                script += "\n# Default inputs\n"
                script += ",".join([f"{k}={repr(v)}" for k, v in func['default_inputs'].items()]) + ","

            if script[-1] == ",":
                script = script[:-1]
            script += ")"
            script += "\n"

            return script

        for func in functions:
            script = _write_func(func, script)
            script += "\n"

        return script

    script = build_script(variables, include_defaults=include_defaults)

    def format_script(script):
        import black
        import isort

        styled = black.format_str(script, mode=black.FileMode())
     
        return isort.code(styled)

    return format_script(script)
